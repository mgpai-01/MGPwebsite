---
name: Industrial Heritage
colors:
  surface: '#faf9f6'
  surface-dim: '#dbdad7'
  surface-bright: '#faf9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f1'
  surface-container: '#efeeeb'
  surface-container-high: '#e9e8e5'
  surface-container-highest: '#e3e2e0'
  on-surface: '#1a1c1a'
  on-surface-variant: '#404941'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f2f1ee'
  outline: '#707970'
  outline-variant: '#c0c9be'
  surface-tint: '#296a40'
  primary: '#0b522a'
  on-primary: '#ffffff'
  primary-container: '#2a6b40'
  on-primary-container: '#a5e9b3'
  inverse-primary: '#92d6a1'
  secondary: '#366947'
  on-secondary: '#ffffff'
  secondary-container: '#b8f0c4'
  on-secondary-container: '#3c6f4c'
  tertiary: '#354c3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c6454'
  on-tertiary-container: '#c4dfcb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#aef2bc'
  primary-fixed-dim: '#92d6a1'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#0a522a'
  secondary-fixed: '#b8f0c4'
  secondary-fixed-dim: '#9dd3aa'
  on-secondary-fixed: '#00210e'
  on-secondary-fixed-variant: '#1d5031'
  tertiary-fixed: '#cee9d4'
  tertiary-fixed-dim: '#b2cdb9'
  on-tertiary-fixed: '#082013'
  on-tertiary-fixed-variant: '#344c3d'
  background: '#faf9f6'
  on-background: '#1a1c1a'
  surface-variant: '#e3e2e0'
typography:
  headline-xl:
    fontFamily: Work Sans
    fontSize: 80px
    fontWeight: '900'
    lineHeight: '1.0'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Work Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Work Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Public Sans
    fontSize: 20px
    fontWeight: '300'
    lineHeight: '1.6'
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  section-padding: 120px
  stack-sm: 16px
  stack-md: 32px
  stack-lg: 64px
---

## Brand & Style

This design system is built to reflect the scale and stability of Manufacturing Green Products. Moving away from the fleeting aesthetics of modern startups, the design focuses on **Industrial Modernism**. This approach pairs the raw, structural honesty of California manufacturing with a clean, editorial layout.

The emotional response should be one of reliability and established presence. The UI uses heavy typographic weights and a grounded color palette to communicate durability. By prioritizing generous whitespace and high-contrast structural blocks, the design system avoids clutter, suggesting an organized and efficient operation that values precision.

## Colors

The palette is rooted in the "Green" of MGP, but interpreted through an industrial lens. The **Primary Green** is reserved for moments of action and brand authority, used deliberately against the **Page BG (off-white)** to maintain a high-end, clean feel.

The **Dark Hero BG** and **Footer BG** provide "weight" to the layout, anchoring the content and providing a professional, established contrast to the lighter page sections. The **Alt Section BG** (Sage and Earthy Off-white) should be used to differentiate service tiers or case studies without breaking the organic, wood-adjacent color story.

## Typography

Typography is the primary driver of the "Industrial" feel in this design system. 
- **Headings:** Utilize uppercase styling with heavy weights (Bold 700 to Black 900). The tight line height and negative letter spacing mimic the stenciled lettering often found in shipping and manufacturing environments.
- **Body:** Uses a clean, accessible sans-serif. The use of "Light 300" for introductory text provides a sophisticated contrast to the heavy headings, while "Regular 400" ensures maximum readability for technical specifications and business copy.
- **Hierarchy:** Maintain a clear distinction between the "heavy" display type and the "airy" body type to reinforce the professional tone.

## Elevation & Depth

This design system avoids traditional drop shadows and floating effects to maintain its "Grounded" and "Established" personality. Depth is achieved through **Tonal Layering** and **Bold Outlines**:
- Use solid color blocks (Alt Section BG) to create a sense of layering.
- UI cards should use a subtle 1px border (#dcdbd8) rather than a shadow.
- Interactive elements may use a hard, 4px offset solid "shadow" in the Primary Green to denote focus, reinforcing a tactile, physical feel rather than a digital glow.

## Shapes

The shape language is primarily **Sharp and Structural**. A minimal border radius (0.25rem) is applied to buttons and form inputs to prevent the UI from feeling hostile, but it should remain subtle. 

Large-scale elements like Hero sections and product images should retain 0px radius (Sharp) to emphasize the heavy-duty nature of wood pallet manufacturing and the "Industrial" aesthetic. High-quality photography of timber and machinery should be cropped into strict rectangular containers.

## Components

### Buttons
Primary buttons are solid rectangles in **Primary Green** with white uppercase text. They should feel heavy and substantial. Secondary buttons use the **Dark Forest** or a ghost style with a 2px border.

### Cards
Cards are used for product categories and location details. They feature a 1px solid border and no shadow. The background should be the **Page BG** or white to stand out against the **Alt Section BG**.

### Input Fields
Inputs are rectangular with a light earthy border. Focus states are indicated by a 2px solid **Primary Green** border. Labels are always uppercase and positioned above the field.

### Chips & Tags
Used for product certifications (e.g., "Heat Treated", "Recycled"). These use the **Sage/Light Green** background with dark text to provide a soft, ecological contrast to the heavy brand green.

### Product Specs List
A custom component featuring a two-column grid with a subtle horizontal rule between items. The left column (label) is uppercase and bold; the right column (value) is light and clean.
# MGP (Manufacturing Green Products) - Project Export

This document contains the consolidated design system tokens, shared components, and page structure for the MGP project, formatted for a **Next.js 14, TypeScript, and Tailwind CSS** project.

---

## 1. Tailwind Configuration (`tailwind.config.ts`)

Add these tokens to your `tailwind.config.ts` to ensure all brand colors and fonts work correctly.

```typescript
import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          green: "#2a6b40",     // Primary Green
          sage: "#6a9e78",      // Sage/Light Green
          hero: "#1c3325",      // Dark Hero BG
          footer: "#141f17",    // Footer BG
          offwhite: "#faf9f6",  // Page BG
          alt: "#f0ede6",       // Alt Section BG
        }
      },
      fontFamily: {
        heading: ["Barlow Condensed", "sans-serif"],
        body: ["Barlow", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
```

---

## 2. Shared Components

### Header (`src/components/Header.tsx`)
```tsx
import Link from 'next/link';

export const Header = () => (
  <nav className="fixed top-0 left-0 w-full flex justify-between items-center px-8 py-4 bg-white/95 backdrop-blur-sm z-50 border-b border-stone-200">
    <div className="flex items-center">
       {/* Replace src with your local logo path */}
      <img src="/logo.png" alt="MGP Logo" className="h-10 w-auto" />
    </div>
    <div className="hidden md:flex space-x-8 font-heading font-bold uppercase tracking-wider text-stone-600">
      <Link href="#products" className="hover:text-brand-green transition-colors">Products</Link>
      <Link href="#industries" className="hover:text-brand-green transition-colors">Industries</Link>
      <Link href="#sustainability" className="hover:text-brand-green transition-colors">Sustainability</Link>
      <Link href="#about" className="hover:text-brand-green transition-colors">About</Link>
    </div>
    <button className="bg-brand-green text-white px-6 py-2 font-heading font-bold uppercase tracking-widest hover:bg-emerald-800 transition-all active:scale-95">
      Get a Quote
    </button>
  </nav>
);
```

### Footer (`src/components/Footer.tsx`)
```tsx
export const Footer = () => (
  <footer className="bg-brand-footer text-stone-400 py-16 px-12 border-t-4 border-brand-green">
    <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
      <div>
        <img src="/logo.png" alt="MGP Logo" className="h-8 w-auto mb-6 brightness-0 invert" />
        <p className="text-xs uppercase tracking-widest leading-relaxed">
          The Inland Empire's leader in reliable, sustainable, and heavy-duty logistics foundations.
        </p>
      </div>
      <div>
        <h4 className="text-white font-heading font-bold uppercase mb-4">Products</h4>
        <ul className="space-y-2 text-xs uppercase tracking-widest">
          <li><a href="#" className="hover:text-brand-green">New Pallets</a></li>
          <li><a href="#" className="hover:text-brand-green">Recycled Pallets</a></li>
          <li><a href="#" className="hover:text-brand-green">Repaired Pallets</a></li>
          <li><a href="#" className="hover:text-brand-green">Custom & Specialty</a></li>
        </ul>
      </div>
      <div>
        <h4 className="text-white font-heading font-bold uppercase mb-4">Logistics</h4>
        <ul className="space-y-2 text-xs uppercase tracking-widest">
          <li><a href="#" className="hover:text-brand-green">Heat Treated</a></li>
          <li><a href="#" className="hover:text-brand-green">Contact Us</a></li>
          <li><a href="#" className="hover:text-brand-green">Privacy Policy</a></li>
        </ul>
      </div>
      <div className="text-xs uppercase tracking-widest leading-loose">
        <h4 className="text-white font-heading font-bold uppercase mb-4">Contact Info</h4>
        <p>8386 Sultana Ave, Fontana, CA</p>
        <p>Mon–Fri: 6am–6pm</p>
        <p>Sat: 6am–3pm</p>
      </div>
    </div>
    <div className="mt-16 pt-8 border-t border-stone-800 text-[10px] text-center tracking-[0.2em]">
      © 2024 MANUFACTURING GREEN PRODUCTS. ALL RIGHTS RESERVED.
    </div>
  </footer>
);
```

---

## 3. Main Page (`src/app/page.tsx`)

This incorporates the **Hero Video** and **Parallax Scroll** structure.

```tsx
'use client';
import { useEffect, useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <main className="bg-brand-offwhite font-body min-h-screen">
      <Header />

      {/* Hero Section with Video & Parallax */}
      <section className="relative h-screen overflow-hidden flex items-center justify-center text-white">
        <div 
          className="absolute inset-0 z-0 scale-110"
          style={{ transform: `translateY(${scrollY * 0.5}px) scale(${1 + scrollY * 0.0001})` }}
        >
          <video 
            autoPlay muted loop playsInline 
            className="w-full h-full object-cover brightness-50"
          >
            <source src="/your-video.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-brand-hero/40"></div>
        </div>

        <div className="relative z-10 text-center max-w-4xl px-6">
          <h1 className="text-6xl md:text-8xl font-heading font-black uppercase leading-none tracking-tighter mb-6">
            The Gold Standard In <br/>Industrial Pallet Solutions
          </h1>
          <p className="text-xl font-light tracking-wide mb-10 max-w-2xl mx-auto">
            The Inland Empire's leader in reliable, sustainable, and heavy-duty logistics foundations.
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <button className="bg-brand-green px-10 py-4 font-heading font-bold uppercase tracking-widest hover:bg-emerald-700 transition-colors">
              Get a Quote
            </button>
            <button className="border-2 border-white px-10 py-4 font-heading font-bold uppercase tracking-widest hover:bg-white hover:text-brand-hero transition-colors">
              View Products
            </button>
          </div>
        </div>
      </section>

      {/* Other sections (Products, Industries, etc.) would follow here using the same componentized approach */}
      
      <Footer />
    </main>
  );
}
```
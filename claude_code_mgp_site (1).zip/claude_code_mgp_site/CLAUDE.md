# Claude Code Instructions

You are working on a Manufacturing Green Products website refinement project.

## Goal
Turn the current static Stitch export into a clean, maintainable, production-ready website while preserving the industrial green manufacturing visual direction.

## Important files
- `index.html` is the main homepage version to start from.
- `docs/DESIGN.md` contains the visual system, colors, typography, spacing, and component guidance.
- `docs/mgp_project_export_guide.md` includes optional Next.js and Tailwind implementation notes.
- `design-options/` contains alternate generated versions and screenshots for comparison.

## Style direction
- Industrial, durable, established, clean, and modern.
- Primary green brand color.
- Heavy uppercase headings.
- Clean readable body text.
- Sharp rectangular layouts.
- Minimal shadows. Prefer borders and solid blocks.
- Strong calls to action for quotes, products, and contact.

## Development notes
- This is currently a static HTML project using Tailwind CDN.
- It can be run with `npm run dev` through Vite or opened directly as `index.html`.
- If converting to Next.js, create normal `src/app`, `src/components`, and Tailwind config files.
- Keep business copy professional and focused on pallet manufacturing, recycling, logistics, heat-treated pallets, and custom pallet solutions.

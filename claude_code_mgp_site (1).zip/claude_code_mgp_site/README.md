# MGP Manufacturing Site Refinement

This folder is ready to drag into Claude Code.

## Run locally

```bash
npm install
npm run dev
```

Or open `index.html` directly in a browser.

## Project structure

- `index.html` is the main selected homepage version, based on the refined industrial design layout.
- `design-options/` contains original Stitch homepage variations converted to `index.html` plus screenshots.
- `docs/DESIGN.md` contains design system notes and brand direction.
- `docs/mgp_project_export_guide.md` contains Next.js/Tailwind conversion notes from the original export.

## Suggested Claude Code prompt

Use this project as the starting point for the Manufacturing Green Products website. First inspect `index.html`, `docs/DESIGN.md`, and the `design-options` folder. Preserve the industrial green manufacturing brand style. Clean up the static HTML, remove duplicate or unused sections, make it responsive, and convert it into a maintainable production-ready structure. If converting to React or Next.js, keep the visual design close to the current homepage and use the design tokens in `docs/DESIGN.md`.
